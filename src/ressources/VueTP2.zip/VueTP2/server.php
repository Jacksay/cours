<?php
///////////////////////////////////////////////////////////////////////////////
//
// API REST à usage pédagogique.
// ! NE PAS UTILISER EN PRODUCTION !
//
///////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
// -- CONFIGURATION
//
// $dataFile : Fichier où sont enregistrées les données
// Il s'agit d'un simple fichier serialisé
$dataFile = __DIR__.'/datas.txt';

// $rootApi : URL de l'api
$rootApi = '/produits';

// Latence
$latence = 0;
//
//
////////////////////////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////////////////////
// -- FONCTIONS USUELLES
/**
 * Retourne $data au format JSON.
 */
function httpJsonResponse( $data ){
  header('Content-Type: application/json');
  die(json_encode($data));
}

const DONE_OK = 200;
const DONE_UPDATED = 200;
const DONE_DELETED = 200;
const DONE_CREATED = 201;

$codes = [
    200 => 'OK',
    201 => 'Created',
    400 => 'Bad Request',
    403 => 'Forbidden',
    404 => 'Not Found',
    410 => 'Gone',
    500 => 'Internal Server Error',
];

/**
 * Génère une en-tête HTTP en fonction du code.
 */
function httpResponse( $code ){
  global $codes;
  header(sprintf("HTTP/1.0 %s %s", $code, $codes[$code]));
}

/**
 * Retourne une réponse HTTP d'erreur.
 */
function httpError($code=404, $message="error"){
  httpResponse($code);
  die($message);
}

function traiterImage(){

}

///////////////////////////////////////////////////////////////////////////////
// -- Match
// Test la ressource demandé (l'extention), ne traite pas.
if (preg_match('/\.(?:png|jpg|jpeg|gif|js|css|html|map|woff||woff2|ttf|svg)$/', $_SERVER["REQUEST_URI"])) {
    return false;
}

///////////////////////////////////////////////////////////////////////////////
// -- API
else {

  sleep($latence);

  //////////////////////////////////////////////////////////////////////////////
  // Pour tester les retours d'erreurs

  if( $_GET && $_GET['error'] ){
    $error = $_GET['error'];
    $msg = sprintf("Erreur pour les tests,  l'API a retournée une erreur %s.", $error);

    if( !array_key_exists($_GET['error'], $codes) ){
      $error = 400;
      $msg = sprintf("Code d'erreur exotique %s...", $_GET['error']);
    }
    if( $error < 400 ){
      $error = 400;
      $msg = sprintf("Code que %s vous avez demandé n'est pas un code d'erreur... mais bon...", $_GET['error']);
    }
    httpError($error, $msg);
  }

  // Récupération de la méthode dans la clef serveur HTTP_X_HTTP_METHOD_OVERRIDE
  // si elle est renseignée, sinon prend la méthode par défaut.
  $method = $_SERVER['REQUEST_METHOD'];

  if( array_key_exists('HTTP_X_HTTP_METHOD_OVERRIDE', $_SERVER) ){
    $method = $_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE'];
  }

  // Ananlyse la REQUEST_URI
  // Cela peut être /server.php/api-url
  // ou /api-uri si le serveur est lancé avec un fichier de boot
  $uri = $_SERVER['REQUEST_URI'];
  if( 0 === strpos($_SERVER['REQUEST_URI'], $_SERVER['SCRIPT_NAME']) ){
    $uri = str_replace($_SERVER['SCRIPT_NAME'], '', $_SERVER['REQUEST_URI']);
  }

  // Affiche un log en sortie
  error_log(sprintf('Accès API [%s] %s', $method, $uri));


  if( $method == "POST" || $method == "PUT" ){
    error_log(" ### DATA SEND : " . count($_POST));
    if( count($_POST) )
      error_log(print_r($_POST, true));

    error_log(" ### FILE SEND : " . count($_FILES));
    if( count($_FILES) )
      error_log(print_r($_FILES, true));

  }

  // Ouverture des données
  $datasString = file_get_contents($dataFile);
  $datas = $datasString ? unserialize($datasString) : [];

  //////////////////////////////////////////////////////////////////////////////
  //
  // API
  //
  //////////////////////////////////////////////////////////////////////////////

  //////////////////////////////////////////////////////////////////////////////
  // [GET] /produits/ (ou /produits)
  // Retourne la liste des données
  if( preg_match('*'.$rootApi.'/?$*', $uri) ){
    if( $method == 'GET' ) {
      httpResponse(DONE_OK);
      httpJsonResponse(array_values($datas));
    }
  //////////////////////////////////////////////////////////////////////////////
  // [POST] /produits/
  // Enregistrement d'une nouvelle entrée
    else if ($method == "POST"){
        /////////////////////////////////////////////////////////////// CREATION
        $data = $_POST;
        $id = uniqid('P');
        $data['id'] = $id;
        $datas[$id] = $data;
        if( $_FILES && $_FILES['image'] && $_FILES['image']['error'] == 0 && $_FILES['image']['size'] > 0 ){
          if (move_uploaded_file($_FILES['image']['tmp_name'], __DIR__.'/images/' . $_FILES['image']['name']) ){
            $data['image'] = '/images/'.$_FILES['image']['name'];
          }
        }
        file_put_contents($dataFile, serialize($datas));
        httpResponse(DONE_CREATED);
        httpJsonResponse($data);
        return true;
    }
  //////////////////////////////////////////////////////////////////////////////
  // [*] /produits
  // Méthode non prise en charge sur cette URL
      else {
        httpError(400, "méthode invalide.");
      }
  }

  //////////////////////////////////////////////////////////////////////////////
  // [*] /produits/:id
  else if ( preg_match('*/produits/([a-zA-Z0-9]+)$*', $uri, $match) ) {
    $id = $match[1];
    switch( $method ){
      //////////////////////////////////////////////////////////////////////////
      // [GET] /produits/:id
      // Retourne l'enregistrement demandé
      case 'GET' :
        if( array_key_exists($id, $datas) ){
          httpJsonResponse($datas);
        } else {
          httpError(404, sprintf("Le produit %s n'existe pas", $id));
        }
        break;
      //////////////////////////////////////////////////////////////////////////
      // [DELETE] /produits/:id
      // Supprime l'enregistrement demandé
      case 'DELETE' :
        if( array_key_exists($id, $datas) ){
          // Simulation d'erreur
          if( $datas[$id]['label'] && $datas[$id]['label'] == 'UNDELETABLE' ){
            httpError(400, sprintf("Le produit %s ne peut pas être supprimé", $id));
            die();
          } else {
            unset($datas[$id]);
            file_put_contents(__DIR__.'/datas.txt', serialize($datas));
            httpResponse(DONE_OK);
          }
          die();
        }
        break;

      //////////////////////////////////////////////////////////////////////////
      // [PUT] /produits/:id
      // Met à jour l'enregistrement demandé
      case 'PUT' :
        if( array_key_exists($id, $datas) ){
          if( $datas[$id]['label'] && $datas[$id]['label'] == "UNEDITABLE" ){
            httpError(400, sprintf("Le produit %s ne peut pas être modifié", $id));
            die();
          } else {

            $oldImage = isset($datas[$id]['image']) ? $datas[$id]['image'] : '';
            $data = $_POST;
            $data['image'] = $oldImage;

            if( $_FILES && $_FILES['image'] && $_FILES['image']['error'] == 0 && $_FILES['image']['size'] > 0 ){
              if (move_uploaded_file($_FILES['image']['tmp_name'], __DIR__.'/images/' . $_FILES['image']['name']) ){
                $data['image'] = '/images/'.$_FILES['image']['name'];
              }
            }
            $data['id'] = $id;
            $datas[$id] = $data;

            file_put_contents(__DIR__.'/datas.txt', serialize($datas));
            httpResponse(DONE_OK);
            httpJsonResponse($data);
          die();
          }
        }
        break;
      //////////////////////////////////////////////////////////////////////////
      // [*] /produits/:id
      // Non prise en charge
      default :
        httpError(400, sprintf("Méthode %s non prise en charge", $method));
        die();
    }
  }
  else {
      httpError(404, sprintf("URL '%s' n'est pas prise en charge par l'API.", $_SERVER['REQUEST_URI']));
  }
}
