(function(){

  //////////////////////////////////////////////////////////////////////////////
  //
  // Fonctions utilitaires
  //
  //////////////////////////////////////////////////////////////////////////////

  /**
   * Générer un clef unique. (Récupérée sur Github)
   * @type {uniqid}
   */
  var uniqid = uniqid = function (pr, en) {
    var pr = pr || '', en = en || false, result;
    this.seed = function (s, w) {
      s = parseInt(s, 10).toString(16);
      return w < s.length ? s.slice(s.length - w) : (w > s.length) ? new Array(1 + (w - s.length)).join('0') + s : s;
    };
    result = pr + this.seed(parseInt(new Date().getTime() / 1000, 10), 8) + this.seed(Math.floor(Math.random() * 0x75bcd15) + 1, 5);
    if (en) result += (Math.random() * 10).toFixed(8).toString();
    return result;
  };

  /**
   * Stratégie de récupération des données à partir des LocalStorage
   * @returns {Array}
   */
  var chargerDepuisLocalStorage = function(){
    if( localStorage && localStorage.getItem("personnages") ){
      return JSON.parse(localStorage.getItem("personnages"));
    }
    return [];
  };

  /**
   * Chargement des données
   */
  var chargerDonnees = function( donneesParDefaut ){
    var dt = chargerDepuisLocalStorage(),
        donneesParDefaut = donneesParDefaut || [];
    if( !dt.length ){
      dt = personnages;
    }
    return dt;
  };

  // Petit cache pour stoquer les noms de personnages
  var personnagesAnchor = {};

  //////////////////////////////////////////////////////////////////////////////
  //
  // Application
  //
  //////////////////////////////////////////////////////////////////////////////
  var config = {
    noimage: 'images/unknow.png'
  };

  var v = new Vue({
    el: "#app",
    data: {
      noimage: config.noimage,
      personnages: chargerDonnees(),
      maisons: maisons,
      recherche: "",
      selectedId: null,
      trie: "nom",
      direction: 1
    },

    created: function(){
      // Création du cache pour le ancre dans les description
      this.updateAnchor();
    },

    // On surveille personnages,
    // si quelque chose change,
    // on actualise le cache
    watch: {
      personnages: {
        handler: 'updateAnchor',
        deep: true
      }
    },

    methods: {
      updateAnchor: function(){
        personnagesAnchor = [];
        this.personnages.forEach(function(p){
          personnagesAnchor.push({
            fullname: p.prenom + ' ' + p.nom,
            anchor: p.id
          });
        });
      },

      vider: function(){
        this.personnages = [];
      },

      trier: function( champ ){
        if( this.trie == champ ){
          this.direction *= -1;
        } else {
          this.trie = champ;
          this.direction = 1;
        }
      },

      /**
       * Mise à jour de l'image.
       *
       * @param personnage
       * @param event
       */
      updateImage: function( personnage, event ){
        var file = event.target.files[0];
        if ( file ){
          var reader = new FileReader();
          reader.addEventListener("load", function(){
            personnage.image = reader.result;
          });
          reader.readAsDataURL(file);
        }
      },

      /**
       * Suppression du personnage.
       *
       * @param personnage
       */
      supprimer: function(personnage){
        for( var i=0; i<this.personnages.length; i++ ){
          if( this.personnages[i].id == personnage.id ){
            this.selectedId = null;
            this.personnages.splice(i, 1);
            return;
          }
        }
      },

      /**
       * Affiche la modal pour modifier le personnage.
       *
       * @param personnage
       */
      editer: function(personnage){
        this.selectedId = personnage.id;

        // On peut utiliser $nextTick pour s'assurer
        // que le modèle est bien à jour
        this.$nextTick(function(){
          $('.modal').modal()
        });
      },

      nouveau: function(){
        var newPerso = {
          id: uniqid('fiche_').toString(),
          surnom: "",
          prenom: "Jon",
          dateCreated: new Date(),
          dateUpdated: new Date(),
          nom: "Doe",
          image: "",
          maison: "",
          description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla natus, atque totam placeat, vero labore. Deleniti dolores, doloribus iste animi officia ratione velit, cupiditate deserunt officiis ad inventore eum! A."
        };
        this.personnages.push(newPerso);
        this.editer(newPerso);
      },

      enregistrer: function(){
        var dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(this.personnages));
        var dlAnchorElem = document.getElementById('downloadAnchorElem');
        dlAnchorElem.setAttribute("href",     dataStr     );
        dlAnchorElem.setAttribute("download", "personnages.json");
        dlAnchorElem.click();
      },

      /**
       * Enregistrement des données dans les localStorages.
       */
      enregistrerLS: function(){
        if( localStorage ){
          localStorage.setItem('personnages', JSON.stringify(this.personnages))
        }
      },

      /**
       * Recalcule la description pour le personnage en ajoutant le format
       * markdown et les ancres vers les autres fiches.
       */
      description: function(personnage){
        var out = personnage.description;
        personnagesAnchor.forEach(function(d){
          out = out.replace(d.fullname, '[' +d.fullname +'](#' +d.anchor + ")");
        });
        return markdown.toHTML(out)
      }
    },

    computed: {
      /** Retourne le personnage selectionné **/
      selected: function(){
        for( var i=0; i<this.personnages.length; i++ ){
          if( this.personnages[i].id == this.selectedId ){
            return this.personnages[i];
          }
        }
        return null;
      },

      /** Liste des personnages filtrées **/
      personnagesFiltres: function(){
        var personnages = [],
            recherche = this.recherche;

        // Filtre sur le nom ou le prénom si la recherche est non-vide
        this.personnages.forEach(function(p){
          if( (recherche.trim() == "") || (p.prenom.search(recherche) > -1 || p.nom.search(recherche)) > -1 ){
            personnages.push(p);
          }
        }.bind(this));

        // Trie des personnages
        personnages.sort(function(p1, p2){
          if( p1[this.trie] < p2[this.trie] ) return -this.direction
          if( p1[this.trie] > p2[this.trie] ) return this.direction
          return 0
        }.bind(this));

        return personnages;
      }
    }
  });
})()
